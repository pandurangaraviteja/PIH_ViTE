"""
train.py  ─  Training & Evaluation Pipeline
Physics-Informed Hybrid ViT–EfficientNet for Low-Light Image Enhancement

Usage:
    python train.py --data_root /path/to/LOL --epochs 100 --batch_size 4

LOL dataset structure expected:
    /path/to/LOL/
        low/    (485 degraded images)
        high/   (485 reference images)
"""

import os, argparse, math, json, time
import numpy as np
import torch
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision.utils import save_image

from model import (
    LOLDataset, PIHViTEffNet, PhysicsAwareLoss,
    psnr, ssim_metric
)


# ─────────────────────────────────────────────
# ARGUMENTS
# ─────────────────────────────────────────────

def get_args():
    p = argparse.ArgumentParser("PIH-ViTE: Low-Light Image Enhancement")
    p.add_argument("--data_root",   type=str,   required=True)
    p.add_argument("--out_dir",     type=str,   default="./outputs")
    p.add_argument("--img_size",    type=int,   default=256)
    p.add_argument("--epochs",      type=int,   default=100)
    p.add_argument("--batch_size",  type=int,   default=4)
    p.add_argument("--lr",          type=float, default=1e-4)
    p.add_argument("--vit_embed",   type=int,   default=256)
    p.add_argument("--vit_depth",   type=int,   default=6)
    p.add_argument("--lambda_rec",  type=float, default=1.0)
    p.add_argument("--lambda_perc", type=float, default=0.1)
    p.add_argument("--lambda_tv",   type=float, default=1e-4)
    p.add_argument("--lambda_ret",  type=float, default=0.05)
    p.add_argument("--lambda_ssim", type=float, default=0.2)
    p.add_argument("--patience",    type=int,   default=10)
    p.add_argument("--save_every",  type=int,   default=10)
    p.add_argument("--num_workers", type=int,   default=4)
    p.add_argument("--seed",        type=int,   default=42)
    p.add_argument("--amp",         action="store_true", help="Use AMP (fp16)")
    return p.parse_args()


# ─────────────────────────────────────────────
# TRAIN EPOCH
# ─────────────────────────────────────────────

def train_epoch(model, loader, optimizer, criterion, device, scaler=None):
    model.train()
    total_loss = 0.0
    loss_parts = {"l1": 0, "perceptual": 0, "tv": 0, "retinex": 0, "ssim": 0}

    for batch_idx, (low, high, _) in enumerate(loader):
        low, high = low.to(device), high.to(device)
        optimizer.zero_grad()

        if scaler is not None:
            from torch.cuda.amp import autocast
            with autocast():
                enhanced, R_hat, L_hat = model(low)
                loss, parts = criterion(enhanced, R_hat, L_hat, high)
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            scaler.step(optimizer)
            scaler.update()
        else:
            enhanced, R_hat, L_hat = model(low)
            loss, parts = criterion(enhanced, R_hat, L_hat, high)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()

        total_loss += loss.item()
        for k in loss_parts:
            loss_parts[k] += parts[k]

    n = len(loader)
    return total_loss / n, {k: v / n for k, v in loss_parts.items()}


# ─────────────────────────────────────────────
# VALIDATION EPOCH
# ─────────────────────────────────────────────

@torch.no_grad()
def validate(model, loader, criterion, device, out_dir=None, epoch=0):
    model.eval()
    total_loss, total_psnr, total_ssim = 0.0, 0.0, 0.0
    n = len(loader)

    for batch_idx, (low, high, fnames) in enumerate(loader):
        low, high = low.to(device), high.to(device)
        enhanced, R_hat, L_hat = model(low)
        loss, _ = criterion(enhanced, R_hat, L_hat, high)
        total_loss += loss.item()
        total_psnr += psnr(enhanced, high)
        total_ssim += ssim_metric(enhanced, high)

        # Save sample outputs every 10 epochs
        if out_dir and batch_idx == 0:
            vis = torch.cat([low[:2], enhanced[:2], high[:2]], dim=0)
            save_image(vis, os.path.join(out_dir, "samples", f"epoch_{epoch:03d}.png"),
                       nrow=2, normalize=False)

    return total_loss / n, total_psnr / n, total_ssim / n


# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────

def main():
    args = get_args()
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")

    # ── Directories ────────────────────────────────────────────────
    os.makedirs(args.out_dir, exist_ok=True)
    os.makedirs(os.path.join(args.out_dir, "samples"), exist_ok=True)
    os.makedirs(os.path.join(args.out_dir, "checkpoints"), exist_ok=True)

    # ── Data ───────────────────────────────────────────────────────
    train_ds = LOLDataset(args.data_root, split="train", img_size=args.img_size)
    val_ds   = LOLDataset(args.data_root, split="test",  img_size=args.img_size)

    train_loader = DataLoader(train_ds, batch_size=args.batch_size,
                              shuffle=True, num_workers=args.num_workers, pin_memory=True)
    val_loader   = DataLoader(val_ds,   batch_size=1,
                              shuffle=False, num_workers=args.num_workers, pin_memory=True)

    print(f"Train: {len(train_ds)} pairs | Val: {len(val_ds)} pairs")

    # ── Model ──────────────────────────────────────────────────────
    model = PIHViTEffNet(
        img_size=args.img_size,
        vit_embed=args.vit_embed,
        vit_depth=args.vit_depth,
    ).to(device)

    n_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"Trainable parameters: {n_params / 1e6:.2f} M")

    # ── Loss & Optimiser ───────────────────────────────────────────
    criterion = PhysicsAwareLoss(
        lambda_rec  = args.lambda_rec,
        lambda_perc = args.lambda_perc,
        lambda_tv   = args.lambda_tv,
        lambda_ret  = args.lambda_ret,
        lambda_ssim = args.lambda_ssim,
    ).to(device)

    optimizer = optim.Adam(
        filter(lambda p: p.requires_grad, model.parameters()),
        lr=args.lr, betas=(0.9, 0.999), weight_decay=1e-5
    )
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="min", factor=0.5, patience=5, verbose=True
    )
    scaler = torch.cuda.amp.GradScaler() if (args.amp and device.type == "cuda") else None

    # ── Training Loop ──────────────────────────────────────────────
    best_psnr   = 0.0
    no_improve  = 0
    history     = []

    for epoch in range(1, args.epochs + 1):
        t0 = time.time()
        train_loss, parts = train_epoch(model, train_loader, optimizer,
                                        criterion, device, scaler)
        val_loss, val_psnr, val_ssim = validate(model, val_loader, criterion,
                                                 device, args.out_dir, epoch)
        scheduler.step(val_loss)
        elapsed = time.time() - t0

        log = {
            "epoch":      epoch,
            "train_loss": round(train_loss, 6),
            "val_loss":   round(val_loss, 6),
            "psnr":       round(val_psnr, 4),
            "ssim":       round(val_ssim, 4),
            "lr":         optimizer.param_groups[0]["lr"],
            **{f"train_{k}": round(v, 6) for k, v in parts.items()},
        }
        history.append(log)

        print(f"[{epoch:3d}/{args.epochs}] "
              f"train={train_loss:.4f}  val={val_loss:.4f}  "
              f"PSNR={val_psnr:.2f}  SSIM={val_ssim:.4f}  "
              f"({elapsed:.1f}s)")

        # Save best
        if val_psnr > best_psnr:
            best_psnr = val_psnr
            no_improve = 0
            torch.save({
                "epoch": epoch, "psnr": val_psnr, "ssim": val_ssim,
                "model": model.state_dict(),
                "optimizer": optimizer.state_dict(),
            }, os.path.join(args.out_dir, "checkpoints", "best.pth"))
            print(f"  ✔ New best PSNR={best_psnr:.2f} saved.")
        else:
            no_improve += 1

        # Periodic checkpoint
        if epoch % args.save_every == 0:
            torch.save(model.state_dict(),
                       os.path.join(args.out_dir, "checkpoints", f"epoch_{epoch:03d}.pth"))

        # Early stopping
        if no_improve >= args.patience:
            print(f"Early stopping at epoch {epoch}. Best PSNR={best_psnr:.2f}")
            break

    # Save training history
    with open(os.path.join(args.out_dir, "history.json"), "w") as f:
        json.dump(history, f, indent=2)
    print(f"\nTraining complete. Best PSNR = {best_psnr:.2f} dB")


if __name__ == "__main__":
    main()
