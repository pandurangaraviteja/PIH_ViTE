"""
Physics-Informed Hybrid ViT-EfficientNet for Low-Light Image Enhancement
========================================================================
Dataset  : LOL (Low-Light) – 485 paired low/normal-light images
Target   : IEEE Transactions on Image Processing
Author   : Panduranga Ravi Teja, UPES Dehradun
"""

import os
import math
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from torchvision.models import efficientnet_b0, EfficientNet_B0_Weights
from PIL import Image


# ─────────────────────────────────────────────
# 1. DATASET
# ─────────────────────────────────────────────

class LOLDataset(Dataset):
    """
    LOL (Low-Light) paired dataset.

    Expected directory layout:
        root/
          low/   ← degraded low-light images  (*.png or *.jpg)
          high/  ← ground-truth normal-light images

    Train split : first 400 pairs
    Test  split : last  85 pairs
    """
    def __init__(self, root: str, split: str = "train", img_size: int = 256):
        assert split in ("train", "test")
        self.split    = split
        self.img_size = img_size

        low_dir  = os.path.join(root, "low")
        high_dir = os.path.join(root, "high")

        all_files = sorted(
            f for f in os.listdir(low_dir)
            if f.lower().endswith((".png", ".jpg", ".jpeg"))
        )

        if split == "train":
            self.files = all_files[:400]
        else:
            self.files = all_files[400:]

        self.low_dir  = low_dir
        self.high_dir = high_dir

        # Physics-guided augmentation for training
        self.train_transform = transforms.Compose([
            transforms.Resize((img_size, img_size)),
            transforms.RandomHorizontalFlip(p=0.5),
            transforms.RandomVerticalFlip(p=0.3),
            transforms.ColorJitter(
                brightness=0.2,          # Δb ~ U(-0.2, 0.2)
                contrast=0.2,            # k  ~ U(0.8, 1.2)
                saturation=0.1,
            ),
            transforms.ToTensor(),       # [0, 1]
        ])

        self.eval_transform = transforms.Compose([
            transforms.Resize((img_size, img_size)),
            transforms.ToTensor(),
        ])

    def __len__(self):
        return len(self.files)

    def _add_gaussian_noise(self, tensor: torch.Tensor, sigma: float = 0.05):
        """Simulate sensor (read) noise: n ~ N(0, sigma²)."""
        return torch.clamp(tensor + torch.randn_like(tensor) * sigma, 0.0, 1.0)

    def _poisson_noise(self, tensor: torch.Tensor, scale: float = 30.0):
        """Simulate Poisson shot noise (signal-dependent)."""
        noisy = torch.poisson(tensor * scale) / scale
        return torch.clamp(noisy, 0.0, 1.0)

    def _elastic_distortion(self, img: Image.Image, alpha: float = 8.0, sigma: float = 4.0):
        """
        Elastic deformation to simulate handheld camera shake / lens distortion.
        magnitude ~ U(-0.08, 0.08) scaled by alpha.
        """
        w, h = img.size
        dx = np.random.uniform(-0.08, 0.08, (h, w)) * alpha
        dy = np.random.uniform(-0.08, 0.08, (h, w)) * alpha

        from scipy.ndimage import gaussian_filter, map_coordinates
        dx = gaussian_filter(dx, sigma)
        dy = gaussian_filter(dy, sigma)

        x, y = np.meshgrid(np.arange(w), np.arange(h))
        map_x = np.clip(x + dx, 0, w - 1).astype(np.float32)
        map_y = np.clip(y + dy, 0, h - 1).astype(np.float32)

        img_np = np.array(img)
        out    = np.zeros_like(img_np)
        for c in range(img_np.shape[2]):
            out[..., c] = map_coordinates(img_np[..., c],
                                          [map_y.ravel(), map_x.ravel()],
                                          order=1).reshape(h, w)
        return Image.fromarray(out.astype(np.uint8))

    def __getitem__(self, idx):
        fname = self.files[idx]

        low_img  = Image.open(os.path.join(self.low_dir,  fname)).convert("RGB")
        high_img = Image.open(os.path.join(self.high_dir, fname)).convert("RGB")

        if self.split == "train":
            # Physics-guided augmentation (same spatial transform for pair)
            if np.random.rand() < 0.4:
                try:
                    low_img = self._elastic_distortion(low_img)
                except Exception:
                    pass  # scipy not always available; skip gracefully

            low  = self.train_transform(low_img)
            high = self.eval_transform(high_img)

            # Physics-based noise on low-light channel
            if np.random.rand() < 0.5:
                low = self._add_gaussian_noise(low, sigma=0.05)
            if np.random.rand() < 0.3:
                low = self._poisson_noise(low)
        else:
            low  = self.eval_transform(low_img)
            high = self.eval_transform(high_img)

        return low, high, fname


# ─────────────────────────────────────────────
# 2. RETINEX DECOMPOSITION HEAD
# ─────────────────────────────────────────────

class RetinexDecompositionHead(nn.Module):
    """
    Lightweight convolutional head that estimates the illumination map L
    and reflectance map R from the encoder feature F, following:
        I ≈ R · L   (element-wise)

    Outputs:
        R_hat  : estimated reflectance (3 ch, range [0,1])
        L_hat  : estimated illumination (1 ch, range [0,1])
        I_hat  : reconstructed image  R_hat * L_hat
    """
    def __init__(self, in_channels: int, spatial_size: int = 8):
        super().__init__()
        mid = in_channels // 2

        self.reflectance_branch = nn.Sequential(
            nn.Conv2d(in_channels, mid, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(mid, 3, 1),
            nn.Sigmoid(),
        )

        self.illumination_branch = nn.Sequential(
            nn.Conv2d(in_channels, mid, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(mid, 1, 1),
            nn.Sigmoid(),
        )

    def forward(self, feat_map: torch.Tensor):
        R = self.reflectance_branch(feat_map)    # (B, 3, H', W')
        L = self.illumination_branch(feat_map)   # (B, 1, H', W')
        I = R * L                                # element-wise Retinex product
        return R, L, I


# ─────────────────────────────────────────────
# 3. LIGHTWEIGHT ViT ENCODER
# ─────────────────────────────────────────────

class PatchEmbedding(nn.Module):
    def __init__(self, img_size=256, patch_size=16, in_ch=3, embed_dim=256):
        super().__init__()
        self.n_patches = (img_size // patch_size) ** 2
        self.proj = nn.Conv2d(in_ch, embed_dim, kernel_size=patch_size, stride=patch_size)

    def forward(self, x):
        x = self.proj(x)                           # (B, D, H/P, W/P)
        B, D, H, W = x.shape
        x = x.flatten(2).transpose(1, 2)           # (B, N, D)
        return x, H, W


class TransformerBlock(nn.Module):
    def __init__(self, dim: int, heads: int = 8, mlp_ratio: float = 4.0, drop: float = 0.1):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn  = nn.MultiheadAttention(dim, heads, dropout=drop, batch_first=True)
        self.norm2 = nn.LayerNorm(dim)
        mlp_dim    = int(dim * mlp_ratio)
        self.mlp   = nn.Sequential(
            nn.Linear(dim, mlp_dim), nn.GELU(),
            nn.Dropout(drop),
            nn.Linear(mlp_dim, dim), nn.Dropout(drop),
        )

    def forward(self, x):
        h, _ = self.attn(self.norm1(x), self.norm1(x), self.norm1(x))
        x = x + h
        x = x + self.mlp(self.norm2(x))
        return x


class ViTEncoder(nn.Module):
    """
    Lightweight ViT encoder:
      patch_size=16, embed_dim=256, depth=6, heads=8
    Output: feature map (B, D, H/P, W/P)
    """
    def __init__(self, img_size=256, patch_size=16,
                 embed_dim=256, depth=6, heads=8):
        super().__init__()
        self.patch_embed = PatchEmbedding(img_size, patch_size, 3, embed_dim)
        n = (img_size // patch_size) ** 2
        self.cls_token = nn.Parameter(torch.zeros(1, 1, embed_dim))
        self.pos_embed = nn.Parameter(torch.zeros(1, n + 1, embed_dim))
        self.blocks    = nn.Sequential(*[TransformerBlock(embed_dim, heads) for _ in range(depth)])
        self.norm      = nn.LayerNorm(embed_dim)
        self._init_weights()

    def _init_weights(self):
        nn.init.trunc_normal_(self.pos_embed, std=0.02)
        nn.init.trunc_normal_(self.cls_token, std=0.02)

    def forward(self, x):
        B = x.shape[0]
        tokens, H, W = self.patch_embed(x)        # (B, N, D)
        cls = self.cls_token.expand(B, -1, -1)
        tokens = torch.cat([cls, tokens], dim=1)  # (B, N+1, D)
        tokens = tokens + self.pos_embed
        tokens = self.blocks(tokens)
        tokens = self.norm(tokens)
        patch_tokens = tokens[:, 1:, :]           # drop CLS
        feat_map = patch_tokens.transpose(1, 2).reshape(B, -1, H, W)
        return feat_map                            # (B, D, H/P, W/P)


# ─────────────────────────────────────────────
# 4. CHANNEL ATTENTION (SE Block)
# ─────────────────────────────────────────────

class ChannelAttention(nn.Module):
    def __init__(self, channels: int, reduction: int = 16):
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channels, channels // reduction),
            nn.ReLU(inplace=True),
            nn.Linear(channels // reduction, channels),
            nn.Sigmoid(),
        )

    def forward(self, x):
        B, C, _, _ = x.shape
        w = self.avg_pool(x).view(B, C)
        w = self.fc(w).view(B, C, 1, 1)
        return x * w


# ─────────────────────────────────────────────
# 5. DECODER (U-Net style)
# ─────────────────────────────────────────────

class DecoderBlock(nn.Module):
    def __init__(self, in_ch: int, skip_ch: int, out_ch: int):
        super().__init__()
        self.up   = nn.ConvTranspose2d(in_ch, out_ch, kernel_size=2, stride=2)
        self.conv = nn.Sequential(
            nn.Conv2d(out_ch + skip_ch, out_ch, 3, padding=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_ch, out_ch, 3, padding=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
        )

    def forward(self, x, skip=None):
        x = self.up(x)
        if skip is not None:
            # Handle size mismatch
            if x.shape != skip.shape:
                skip = F.interpolate(skip, size=x.shape[2:], mode='bilinear', align_corners=False)
            x = torch.cat([x, skip], dim=1)
        return self.conv(x)


# ─────────────────────────────────────────────
# 6. MAIN MODEL
# ─────────────────────────────────────────────

class PIHViTEffNet(nn.Module):
    """
    Physics-Informed Hybrid ViT–EfficientNet for Low-Light Image Enhancement (PIH-ViTE)

    Architecture:
      ┌─ ViT Encoder    (global Retinex-aware attention) ──────────────────┐
      │                                                                      │
      Input ──┤                                                              ├──► Decoder ──► Enhanced I_hat
      │                                                                      │
      └─ EfficientNet-B0 (local feature extraction) ───────────────────────┘
             + Physics constraint block (Retinex decomposition head)

    Outputs:
      enhanced : final enhanced image (B, 3, H, W)
      R_hat    : reflectance estimate
      L_hat    : illumination estimate
    """

    def __init__(self, img_size: int = 256, vit_embed: int = 256, vit_depth: int = 6):
        super().__init__()

        # ── ViT branch ──────────────────────────────────────────────
        self.vit = ViTEncoder(
            img_size=img_size, patch_size=16,
            embed_dim=vit_embed, depth=vit_depth, heads=8
        )
        # ViT output: (B, 256, 16, 16)

        # ── EfficientNet-B0 branch (pretrained, frozen stem) ────────
        eff = efficientnet_b0(weights=EfficientNet_B0_Weights.IMAGENET1K_V1)
        # Extract feature stages for skip connections
        self.eff_stage0 = eff.features[0]           # stride 2  → 128×128, ch=32
        self.eff_stage1 = eff.features[1]           # stride 1  → 128×128, ch=16
        self.eff_stage2 = eff.features[2]           # stride 2  →  64×64,  ch=24
        self.eff_stage3 = eff.features[3]           # stride 2  →  32×32,  ch=40
        self.eff_stage4 = eff.features[4]           # stride 2  →  16×16,  ch=80
        self.eff_stage5 = eff.features[5]           # stride 1  →  16×16,  ch=112
        self.eff_stage6 = eff.features[6]           # stride 2  →   8×8,   ch=192
        self.eff_stage7 = eff.features[7]           # stride 1  →   8×8,   ch=320

        # Freeze early EfficientNet layers
        for p in list(self.eff_stage0.parameters()) + list(self.eff_stage1.parameters()):
            p.requires_grad = False

        # ── Physics Constraint Block ─────────────────────────────────
        # operates on fused bottleneck features
        fused_ch = vit_embed + 320       # 256 + 320 = 576
        self.retinex_head = RetinexDecompositionHead(fused_ch, spatial_size=8)

        # Project fused to decoder channel budget
        self.bottleneck = nn.Sequential(
            nn.Conv2d(fused_ch, 256, 1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
        )

        # ── Channel Attention ────────────────────────────────────────
        self.ca = ChannelAttention(256, reduction=16)

        # ── Decoder (U-Net style) ────────────────────────────────────
        self.dec4 = DecoderBlock(256, 192, 128)   # 8→16
        self.dec3 = DecoderBlock(128,  80,  64)   # 16→32
        self.dec2 = DecoderBlock( 64,  40,  32)   # 32→64
        self.dec1 = DecoderBlock( 32,  24,  16)   # 64→128
        self.dec0 = DecoderBlock( 16,  16,   8)   # 128→256

        # Final reconstruction head
        self.final = nn.Sequential(
            nn.Conv2d(8, 8, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(8, 3, 1),
            nn.Sigmoid(),
        )

    def _eff_features(self, x):
        """Extract multi-scale EfficientNet features for skip connections."""
        s0 = self.eff_stage0(x)    # (B,  32, H/2,  W/2)
        s1 = self.eff_stage1(s0)   # (B,  16, H/2,  W/2)
        s2 = self.eff_stage2(s1)   # (B,  24, H/4,  W/4)
        s3 = self.eff_stage3(s2)   # (B,  40, H/8,  W/8)
        s4 = self.eff_stage4(s3)   # (B,  80, H/16, W/16)
        s5 = self.eff_stage5(s4)   # (B, 112, H/16, W/16)
        s6 = self.eff_stage6(s5)   # (B, 192, H/32, W/32)
        s7 = self.eff_stage7(s6)   # (B, 320, H/32, W/32)
        return s1, s2, s3, s4, s6, s7

    def forward(self, x):
        # ── Dual-branch encoding ─────────────────────────────────────
        vit_feat = self.vit(x)                          # (B, 256, 16, 16) for 256×256
        s1, s2, s3, s4, s6, s7 = self._eff_features(x)

        # Align spatial sizes before fusion
        vit_up = F.interpolate(vit_feat, size=s7.shape[2:], mode='bilinear', align_corners=False)
        fused  = torch.cat([vit_up, s7], dim=1)         # (B, 576, 8, 8)

        # ── Physics Constraint Block ─────────────────────────────────
        R_hat, L_hat, I_retinex = self.retinex_head(fused)

        # ── Bottleneck + Channel Attention ───────────────────────────
        bot = self.bottleneck(fused)                     # (B, 256, 8, 8)
        bot = self.ca(bot)

        # ── Decode with skip connections ─────────────────────────────
        d4 = self.dec4(bot, s6)   # (B, 128, 16, 16)
        d3 = self.dec3(d4,  s4)   # (B,  64, 32, 32)
        d2 = self.dec2(d3,  s3)   # (B,  32, 64, 64)
        d1 = self.dec1(d2,  s2)   # (B,  16,128,128)
        d0 = self.dec0(d1,  s1)   # (B,   8,256,256)

        enhanced = self.final(d0)                        # (B, 3, 256, 256)

        return enhanced, R_hat, L_hat


# ─────────────────────────────────────────────
# 7. PHYSICS-AWARE LOSS FUNCTIONS
# ─────────────────────────────────────────────

class TotalVariationLoss(nn.Module):
    """Isotropic TV loss — encourages smooth illumination maps."""
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        dh = torch.abs(x[:, :, 1:, :]  - x[:, :, :-1, :])
        dw = torch.abs(x[:, :, :, 1:]  - x[:, :, :, :-1])
        return dh.mean() + dw.mean()


class PerceptualLoss(nn.Module):
    """
    VGG-16 feature-matching loss (relu2_2 and relu3_3).
    Captures structural and textural similarity.
    """
    def __init__(self):
        super().__init__()
        from torchvision.models import vgg16, VGG16_Weights
        vgg   = vgg16(weights=VGG16_Weights.IMAGENET1K_V1).features
        self.slice1 = nn.Sequential(*list(vgg)[:9]).eval()   # relu2_2
        self.slice2 = nn.Sequential(*list(vgg)[9:16]).eval() # relu3_3
        for p in self.parameters():
            p.requires_grad = False

        # ImageNet normalisation
        self.register_buffer('mean', torch.tensor([0.485, 0.456, 0.406]).view(1,3,1,1))
        self.register_buffer('std',  torch.tensor([0.229, 0.224, 0.225]).view(1,3,1,1))

    def forward(self, pred: torch.Tensor, target: torch.Tensor):
        pred_n   = (pred   - self.mean) / self.std
        target_n = (target - self.mean) / self.std
        h1 = F.l1_loss(self.slice1(pred_n), self.slice1(target_n))
        f1 = self.slice1(pred_n)
        f2 = self.slice1(target_n)
        h2 = F.l1_loss(self.slice2(f1), self.slice2(f2))
        return h1 + h2


class RetinexConsistencyLoss(nn.Module):
    """
    Physics consistency: the product R·L (upsampled to input resolution)
    should approximate the enhanced output, not the low-light input.
    Ensures the decomposition is physically meaningful.
    """
    def forward(self, R_hat, L_hat, enhanced, target):
        L_up = F.interpolate(L_hat, size=enhanced.shape[2:], mode='bilinear', align_corners=False)
        R_up = F.interpolate(R_hat, size=enhanced.shape[2:], mode='bilinear', align_corners=False)
        reconstruction = R_up * L_up
        return F.l1_loss(reconstruction, target)


class IlluminationSmoothnessLoss(nn.Module):
    """
    Smoothness prior on the illumination map L:
    neighbouring pixels should not differ abruptly.
    """
    def __init__(self):
        super().__init__()
        self.tv = TotalVariationLoss()

    def forward(self, L_hat):
        return self.tv(L_hat)


class PhysicsAwareLoss(nn.Module):
    """
    Combined physics-aware loss:
        L_total = λ_rec  · L1
                + λ_perc · L_perceptual
                + λ_tv   · L_TV(L_hat)
                + λ_ret  · L_Retinex
                + λ_ssim · (1 - SSIM)
    """
    def __init__(self,
                 lambda_rec:  float = 1.0,
                 lambda_perc: float = 0.1,
                 lambda_tv:   float = 1e-4,
                 lambda_ret:  float = 0.05,
                 lambda_ssim: float = 0.2):
        super().__init__()
        self.lambda_rec  = lambda_rec
        self.lambda_perc = lambda_perc
        self.lambda_tv   = lambda_tv
        self.lambda_ret  = lambda_ret
        self.lambda_ssim = lambda_ssim

        self.perceptual      = PerceptualLoss()
        self.tv_loss         = TotalVariationLoss()
        self.retinex_consist = RetinexConsistencyLoss()
        self.illum_smooth    = IlluminationSmoothnessLoss()

    def ssim_loss(self, pred, target, window_size=11):
        """Differentiable SSIM (simplified single-scale)."""
        C1, C2 = 0.01**2, 0.03**2
        mu1 = F.avg_pool2d(pred,   window_size, stride=1, padding=window_size//2)
        mu2 = F.avg_pool2d(target, window_size, stride=1, padding=window_size//2)
        mu1_sq = mu1 * mu1; mu2_sq = mu2 * mu2; mu12 = mu1 * mu2
        s1  = F.avg_pool2d(pred*pred,     window_size, 1, window_size//2) - mu1_sq
        s2  = F.avg_pool2d(target*target, window_size, 1, window_size//2) - mu2_sq
        s12 = F.avg_pool2d(pred*target,   window_size, 1, window_size//2) - mu12
        ssim_map = ((2*mu12 + C1)*(2*s12 + C2)) / ((mu1_sq+mu2_sq+C1)*(s1+s2+C2))
        return 1 - ssim_map.mean()

    def forward(self, enhanced, R_hat, L_hat, target):
        l_rec  = F.l1_loss(enhanced, target)
        l_perc = self.perceptual(enhanced, target)
        l_tv   = self.tv_loss(L_hat)
        l_ret  = self.retinex_consist(R_hat, L_hat, enhanced, target)
        l_ssim = self.ssim_loss(enhanced, target)

        total = (self.lambda_rec  * l_rec
               + self.lambda_perc * l_perc
               + self.lambda_tv   * l_tv
               + self.lambda_ret  * l_ret
               + self.lambda_ssim * l_ssim)

        return total, {
            "l1":       l_rec.item(),
            "perceptual": l_perc.item(),
            "tv":       l_tv.item(),
            "retinex":  l_ret.item(),
            "ssim":     l_ssim.item(),
        }


# ─────────────────────────────────────────────
# 8. EVALUATION METRICS
# ─────────────────────────────────────────────

def psnr(pred: torch.Tensor, target: torch.Tensor, max_val: float = 1.0) -> float:
    mse = F.mse_loss(pred, target).item()
    if mse == 0:
        return float("inf")
    return 10 * math.log10(max_val ** 2 / mse)


def ssim_metric(pred: torch.Tensor, target: torch.Tensor) -> float:
    """Full-reference SSIM (mean over batch)."""
    C1, C2 = 0.01**2, 0.03**2
    ws = 11
    mu1 = F.avg_pool2d(pred,   ws, 1, ws//2)
    mu2 = F.avg_pool2d(target, ws, 1, ws//2)
    mu1_sq = mu1*mu1; mu2_sq = mu2*mu2; mu12 = mu1*mu2
    s1  = F.avg_pool2d(pred*pred,     ws, 1, ws//2) - mu1_sq
    s2  = F.avg_pool2d(target*target, ws, 1, ws//2) - mu2_sq
    s12 = F.avg_pool2d(pred*target,   ws, 1, ws//2) - mu12
    ssim_map = ((2*mu12+C1)*(2*s12+C2)) / ((mu1_sq+mu2_sq+C1)*(s1+s2+C2))
    return ssim_map.mean().item()


def lpips_approx(pred: torch.Tensor, target: torch.Tensor) -> float:
    """
    Approximate LPIPS using VGG relu2_2 L2 distance (no lpips package needed).
    True LPIPS requires pip install lpips; swap this function if available.
    """
    from torchvision.models import vgg16, VGG16_Weights
    vgg = vgg16(weights=VGG16_Weights.IMAGENET1K_V1).features[:9].eval()
    vgg = vgg.to(pred.device)
    with torch.no_grad():
        f1 = vgg(pred)
        f2 = vgg(target)
    return F.mse_loss(f1, f2).item()
