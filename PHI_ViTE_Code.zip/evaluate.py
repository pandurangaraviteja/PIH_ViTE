"""
evaluate.py  ─  Full Evaluation Suite
Computes PSNR, SSIM, LPIPS for all baselines and our model on the LOL test set.
Also generates comparison visualisations and saves result tables.

Usage:
    python evaluate.py --data_root /path/to/LOL --checkpoint outputs/checkpoints/best.pth
"""

import os, argparse, json, math
import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torchvision.utils import save_image
from torchvision.models import efficientnet_b0, EfficientNet_B0_Weights
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

from model import LOLDataset, PIHViTEffNet, psnr, ssim_metric


# ─────────────────────────────────────────────
# BASELINE MODELS (for comparison in Table 1)
# ─────────────────────────────────────────────

class RetinexNetSimple(torch.nn.Module):
    """Simplified RetinexNet decomposition-based baseline."""
    def __init__(self):
        super().__init__()
        self.decom = torch.nn.Sequential(
            torch.nn.Conv2d(3, 32, 3, padding=1), torch.nn.ReLU(),
            torch.nn.Conv2d(32, 32, 3, padding=1), torch.nn.ReLU(),
            torch.nn.Conv2d(32, 4, 1), torch.nn.Sigmoid(),
        )

    def forward(self, x):
        out   = self.decom(x)
        R     = out[:, :3, :, :]
        L     = out[:, 3:4, :, :].expand_as(R)
        gamma = 0.4
        L_adj = torch.pow(torch.clamp(L, 1e-6, 1), gamma)
        return torch.clamp(R * L_adj, 0, 1)


class EfficientNetEnhancer(torch.nn.Module):
    """EfficientNet-B0 encoder + simple decoder (no physics)."""
    def __init__(self):
        super().__init__()
        eff = efficientnet_b0(weights=EfficientNet_B0_Weights.IMAGENET1K_V1)
        self.encoder = eff.features
        self.decoder = torch.nn.Sequential(
            torch.nn.ConvTranspose2d(1280, 256, 4, 2, 1),
            torch.nn.ReLU(),
            torch.nn.ConvTranspose2d(256, 64, 4, 2, 1),
            torch.nn.ReLU(),
            torch.nn.ConvTranspose2d(64, 32, 4, 2, 1),
            torch.nn.ReLU(),
            torch.nn.ConvTranspose2d(32, 16, 4, 2, 1),
            torch.nn.ReLU(),
            torch.nn.ConvTranspose2d(16, 3, 4, 2, 1),
            torch.nn.Sigmoid(),
        )

    def forward(self, x):
        feat = self.encoder(x)
        return self.decoder(feat)


# ─────────────────────────────────────────────
# HISTOGRAM EQUALISATION BASELINE (classical)
# ─────────────────────────────────────────────

def histogram_equalization(batch: torch.Tensor) -> torch.Tensor:
    """Apply CLAHE-style histogram equalisation on V channel (HSV)."""
    out = []
    for img in batch:
        np_img = (img.permute(1,2,0).cpu().numpy() * 255).astype(np.uint8)
        import cv2
        hsv = cv2.cvtColor(np_img, cv2.COLOR_RGB2HSV)
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
        hsv[..., 2] = clahe.apply(hsv[..., 2])
        enhanced = cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB).astype(np.float32) / 255.
        out.append(torch.from_numpy(enhanced).permute(2,0,1))
    return torch.stack(out).to(batch.device)


# ─────────────────────────────────────────────
# EVALUATION FUNCTION
# ─────────────────────────────────────────────

@torch.no_grad()
def evaluate_model(model, loader, device, name="Model", use_clahe=False):
    if not use_clahe:
        model.eval()
    psnr_list, ssim_list = [], []

    for low, high, _ in loader:
        low, high = low.to(device), high.to(device)
        if use_clahe:
            try:
                enhanced = histogram_equalization(low)
            except ImportError:
                # Fallback: gamma correction
                enhanced = torch.pow(low, 0.5)
        else:
            out = model(low)
            enhanced = out[0] if isinstance(out, tuple) else out
        psnr_list.append(psnr(enhanced, high))
        ssim_list.append(ssim_metric(enhanced, high))

    mean_psnr = np.mean(psnr_list)
    mean_ssim = np.mean(ssim_list)
    print(f"  {name:<35s}  PSNR={mean_psnr:.2f} dB  SSIM={mean_ssim:.4f}")
    return mean_psnr, mean_ssim


# ─────────────────────────────────────────────
# ABLATION STUDY
# ─────────────────────────────────────────────

def run_ablation(args, device, val_loader):
    """
    Ablation: evaluate model variants by zeroing out loss components
    (simulated via λ settings at training time; here we compare checkpoints
     if available, otherwise report from training history).
    """
    ablation_results = {
        "Full model (all physics)":          {"psnr": None, "ssim": None},
        "No TV loss (λ_TV=0)":               {"psnr": None, "ssim": None},
        "No Retinex loss (λ_ret=0)":         {"psnr": None, "ssim": None},
        "No perceptual loss (λ_perc=0)":     {"psnr": None, "ssim": None},
        "No physics augmentation":            {"psnr": None, "ssim": None},
    }
    print("\nAblation study checkpoints would be needed for full results.")
    print("Training with different λ settings produces Table 3 in the paper.")
    return ablation_results


# ─────────────────────────────────────────────
# VISUALISATION
# ─────────────────────────────────────────────

@torch.no_grad()
def generate_visual_comparison(model, loader, device, out_dir, n_samples=4):
    model.eval()
    samples_low, samples_high, samples_enh = [], [], []

    for i, (low, high, _) in enumerate(loader):
        if i >= n_samples:
            break
        low, high = low.to(device), high.to(device)
        enhanced, R_hat, L_hat = model(low)
        samples_low.append(low[0].cpu())
        samples_high.append(high[0].cpu())
        samples_enh.append(enhanced[0].cpu())

    fig, axes = plt.subplots(n_samples, 3, figsize=(12, 4 * n_samples))
    titles = ["Low-light input", "Enhanced (Ours)", "Ground truth"]
    cols   = [samples_low, samples_enh, samples_high]

    for row in range(n_samples):
        for col_idx, (col_data, title) in enumerate(zip(cols, titles)):
            ax = axes[row, col_idx]
            img = col_data[row].permute(1,2,0).numpy().clip(0, 1)
            ax.imshow(img)
            if row == 0:
                ax.set_title(title, fontsize=13, fontweight='bold')
            p = psnr(
                col_data[row].unsqueeze(0),
                samples_high[row].unsqueeze(0)
            ) if col_idx < 2 else float('inf')
            if col_idx == 1:
                ax.set_xlabel(f"PSNR={p:.2f} dB", fontsize=10)
            ax.axis("off")

    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "visual_comparison.pdf"), dpi=150, bbox_inches='tight')
    plt.savefig(os.path.join(out_dir, "visual_comparison.png"), dpi=150, bbox_inches='tight')
    print(f"Visual comparison saved.")


# ─────────────────────────────────────────────
# PLOT TRAINING CURVES
# ─────────────────────────────────────────────

def plot_training_curves(history_path: str, out_dir: str):
    with open(history_path) as f:
        history = json.load(f)

    epochs     = [h["epoch"]      for h in history]
    train_loss = [h["train_loss"] for h in history]
    val_loss   = [h["val_loss"]   for h in history]
    psnr_vals  = [h["psnr"]       for h in history]
    ssim_vals  = [h["ssim"]       for h in history]

    fig, axes = plt.subplots(1, 3, figsize=(15, 4))

    axes[0].plot(epochs, train_loss, label="Train Loss", color="#185FA5")
    axes[0].plot(epochs, val_loss,   label="Val Loss",   color="#D85A30")
    axes[0].set_xlabel("Epoch"); axes[0].set_ylabel("Loss")
    axes[0].set_title("Loss Convergence"); axes[0].legend()
    axes[0].grid(alpha=0.3)

    axes[1].plot(epochs, psnr_vals, color="#0F6E56", linewidth=2)
    axes[1].set_xlabel("Epoch"); axes[1].set_ylabel("PSNR (dB)")
    axes[1].set_title("PSNR on LOL Test Set"); axes[1].grid(alpha=0.3)

    axes[2].plot(epochs, ssim_vals, color="#533AB7", linewidth=2)
    axes[2].set_xlabel("Epoch"); axes[2].set_ylabel("SSIM")
    axes[2].set_title("SSIM on LOL Test Set"); axes[2].grid(alpha=0.3)

    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "training_curves.pdf"), dpi=150, bbox_inches='tight')
    plt.savefig(os.path.join(out_dir, "training_curves.png"), dpi=150, bbox_inches='tight')
    print("Training curves saved.")


# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data_root",   type=str, required=True)
    p.add_argument("--checkpoint",  type=str, required=True)
    p.add_argument("--out_dir",     type=str, default="./eval_results")
    p.add_argument("--img_size",    type=int, default=256)
    p.add_argument("--vit_embed",   type=int, default=256)
    p.add_argument("--vit_depth",   type=int, default=6)
    p.add_argument("--history",     type=str, default="outputs/history.json")
    args = p.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # ── Load test data ─────────────────────────────────────────────
    val_ds = LOLDataset(args.data_root, split="test", img_size=args.img_size)
    val_loader = DataLoader(val_ds, batch_size=1, shuffle=False, num_workers=2)
    print(f"Test set: {len(val_ds)} pairs\n")

    # ── Load our model ─────────────────────────────────────────────
    model = PIHViTEffNet(args.img_size, args.vit_embed, args.vit_depth).to(device)
    ckpt  = torch.load(args.checkpoint, map_location=device)
    model.load_state_dict(ckpt["model"])

    # ── Baselines ─────────────────────────────────────────────────
    retinex = RetinexNetSimple().to(device)
    effnet  = EfficientNetEnhancer().to(device)

    print("─" * 65)
    print("Quantitative Evaluation on LOL Test Set (85 pairs)")
    print("─" * 65)

    results = {}
    results["CLAHE (classical)"]                  = evaluate_model(None, val_loader, device, "CLAHE (classical)",             use_clahe=True)
    results["RetinexNet (simplified)"]            = evaluate_model(retinex, val_loader, device, "RetinexNet (simplified)")
    results["EfficientNet-B0 (no physics)"]       = evaluate_model(effnet,  val_loader, device, "EfficientNet-B0 (no physics)")
    results["PIH-ViTE Ours (physics-informed)"]   = evaluate_model(model,   val_loader, device, "PIH-ViTE (ours, full physics)")
    print("─" * 65)

    # Save results
    with open(os.path.join(args.out_dir, "results.json"), "w") as f:
        json.dump({k: {"psnr": v[0], "ssim": v[1]} for k, v in results.items()}, f, indent=2)

    # ── Visual comparison ─────────────────────────────────────────
    generate_visual_comparison(model, val_loader, device, args.out_dir)

    # ── Training curves ───────────────────────────────────────────
    if os.path.exists(args.history):
        plot_training_curves(args.history, args.out_dir)

    print(f"\nAll results saved to {args.out_dir}/")


if __name__ == "__main__":
    main()
